import React from "react";
import { Button, Typography } from "antd";
import jsPDF from "jspdf";

const { Text } = Typography;

const Form20 = () => {
	const handleExportPdf = async () => {
		const doc = new jsPDF("p", "mm", "a4");
		const pageWidth = doc.internal.pageSize.getWidth();
		const marginLeft = 16;
		const marginRight = 16;
		const printableWidth = pageWidth - marginLeft - marginRight;
		const rightColWidth = 48; // fixed area for dotted fields on the right
		let y = 18;

		const addTitle = (t, size = 11, style = "bold") => {
			doc.setFont("helvetica", style);
			doc.setFontSize(size);
			doc.text(t, pageWidth / 2, y, { align: "center" });
			y += 6;
		};

		const addPara = (text, gap = 3.5, size = 10.2, style = "normal") => {
			doc.setFont("helvetica", style);
			doc.setFontSize(size);
			const lines = doc.splitTextToSize(text, printableWidth);
			doc.text(lines, marginLeft, y, { lineHeightFactor: 1.35 });
			y += lines.length * 5.2 + gap;
		};

		// Renders a numbered left description with an optional dotted field column on the right
		const addItem = (numText, desc, withRightDots = true) => {
            doc.setFont("helvetica", "normal");
            doc.setFontSize(10.2);
          
            const leftColumnWidth = printableWidth - 50; // 50mm reserved for right column
            const rightColumnX = marginLeft + leftColumnWidth;
          
            // Add number + description in left column
            const leftLines = doc.splitTextToSize(numText ? `${numText} ${desc}` : desc, leftColumnWidth);
            doc.text(leftLines, marginLeft, y, { lineHeightFactor: 1.35 });
          
            // Add right column dots if needed
            if (withRightDots) {
              const blockHeight = leftLines.length * 5.2; // approximate height
              doc.text("....................................", rightColumnX, y, { align: "left" });
              y += blockHeight + 3; // move Y below the row
            } else {
              y += leftLines.length * 5.2 + 3; // move Y below the row
            }
          };

		// New function for hierarchical layout with nested numbering
		const addHierarchicalItem = (mainNum, nestedNum, desc, withRightDots = true, indentLevel = 0) => {
			doc.setFont("helvetica", "normal");
			doc.setFontSize(10.2);
			
			const leftColumnWidth = printableWidth - 50; // 50mm reserved for right column
			const rightColumnX = marginLeft + leftColumnWidth;
			
			// Calculate indentation based on level
			const baseIndent = marginLeft;
			const indentPerLevel = 8; // 8mm per indent level
			const currentIndent = baseIndent + (indentLevel * indentPerLevel);
			
			// Create the text with proper spacing
			let fullText = "";
			if (mainNum && nestedNum) {
				// For nested items like "5(A)" or "(a)"
				fullText = `${mainNum}${nestedNum} ${desc}`;
			} else if (mainNum) {
				// For main items like "1."
				fullText = `${mainNum} ${desc}`;
			} else {
				// For sub-items without main number
				fullText = desc;
			}
			
			// Split text to fit in the available width (accounting for indentation)
			const availableWidth = leftColumnWidth - (currentIndent - marginLeft);
			const leftLines = doc.splitTextToSize(fullText, availableWidth);
			
			// Draw the text with proper indentation
			doc.text(leftLines, currentIndent, y, { lineHeightFactor: 1.35 });
			
			// Add right column dots if needed
			if (withRightDots) {
				const blockHeight = leftLines.length * 5.2;
				doc.text("....................................", rightColumnX, y, { align: "left" });
				y += blockHeight + 3;
			} else {
				y += leftLines.length * 5.2 + 3;
			}
		};

		// Function for inline paragraphs with full width to dotted lines
		const addInlineParagraph = (text, indentLevel = 1, gap = 3.5) => {
			doc.setFont("helvetica", "normal");
			doc.setFontSize(10.2);
			
			// Calculate indentation - paragraphs are indented more than nested items
			const baseIndent = marginLeft;
			const indentPerLevel = 8;
			const paragraphIndent = baseIndent + (indentLevel * indentPerLevel);
			
			// Use full width to dotted lines (same as main items)
			const leftColumnWidth = printableWidth - 50; // 50mm reserved for right column
			const availableWidth = leftColumnWidth - (paragraphIndent - marginLeft);
			
			const lines = doc.splitTextToSize(text, availableWidth);
			doc.text(lines, paragraphIndent, y, { lineHeightFactor: 1.35 });
			y += lines.length * 5.2 + gap;
		};

		// Headings
		addTitle("FORM 20", 11, "bold");
		addTitle("(Refer Rule 47 and Rule 53A)", 9.5, "italic");
		addTitle("APPLICATION FOR REGISTRATION OR TEMPORARY REGISTRATION", 10.5, "normal");
		addTitle("OF A MOTOR VEHICLE", 10.5, "normal");
		addPara("\t(To be made in duplicate if the vehicle is held under an agreement of Hire-Purchase/Lease/ Hypothecation and duplicate copy with the endorsement of the Registering Authority to be returned to the Financier simultaneously on Registration of motor vehicle)", 6);

		// To block
		doc.setFont("helvetica", "normal");
		doc.setFontSize(10.2);
		doc.text("To", marginLeft, y); y += 6;
		doc.text("The Licensing Authority,", marginLeft, y); y += 6;
		doc.text("..........................................................", marginLeft, y); y += 6;

		// const pageWidth = doc.internal.pageSize.getWidth() - 10;
		
		// Numbered items - Page 1 using hierarchical layout
		addHierarchicalItem("1.", null, "Full Name of person to be registered as Registered owner", true);
		addInlineParagraph("Son/Wife/Daughter of", 1, 2);
		
		addHierarchicalItem("2.", null, "Age of person to be registered as Registered owner", true);
		
		addHierarchicalItem("3.", null, "Permanent address", true);
		addInlineParagraph("(Electoral Roll/ Life Insurance Policy/ Passport/ Pay slip issued by any office of the Central Government/ State Government or a local body / Any other document or documents as may be prescribed by the State Government/ Affidavit sworn before an Executive Magistrate or a First Class Judicial Magistrate or a Notary Public to be enclosed)", 1, 2);
		
		addHierarchicalItem("4.", null, "Temporary address/ Official address, if any", true);
		
		addHierarchicalItem("4A.", null, "Ownership type", true);
		
		// Ownership types with hierarchical numbering
		const ownershipTypes = [
			{ num: "1.", desc: "AUTONOMOUS BODY" },
			{ num: "2.", desc: "CENTRAL GOVERNMENT" },
			{ num: "3.", desc: "CHARITABLE TRUST" },
			{ num: "4.", desc: "DRIVING TRAINING SCHOOL" },
			{ num: "5.", desc: "DIVYANGJAN" },
			{ num: "6.", desc: "EDUCATIONAL INSTITUTE" },
			{ num: "7.", desc: "FIRM" },
			{ num: "8.", desc: "GOVERNMENT UNDERTAKING" },
			{ num: "9.", desc: "INDIVIDUAL" },
			{ num: "10.", desc: "LOCAL AUTHORITY" },
			{ num: "11.", desc: "MULTIPLE OWNER" },
			{ num: "12.", desc: "POLICE DEPARTMENT" },
			{ num: "13.", desc: "STATE GOVERNMENT" },
			{ num: "14.", desc: "STATE TRANSPORT CORPORATION OR DEPARTMENT" },
		];
		
		ownershipTypes.forEach((item) => {
			addHierarchicalItem(item.num, null, item.desc, false, 1);
		});
		
		// Special case for DIVYANGJAN with nested items
		addHierarchicalItem("", "(a)", "AVAILING GST CONCESSION", false, 2);
		addHierarchicalItem("", "(b)", "WITHOUT AVAILING GST CONCESSION", false, 2);

		// Page 2 for items 5 - 28 using hierarchical layout
		doc.addPage();
		y = 18;
		
		addHierarchicalItem("5.", null, "Duration of stay at the present address", true);
		addHierarchicalItem("5", "(A)", "Mobile number of the owner of the vehicle", true);
		
		addHierarchicalItem("6.", null, "PAN number (optional)", true);
		addHierarchicalItem("7.", null, "Place of birth", true);
		addHierarchicalItem("8.", null, "If place of birth is outside India, when migrated to India", true);
		
		addHierarchicalItem("9(A).", null, "Name of the nominee", true);
		addHierarchicalItem("9(B).", null, "Relationship with the nominee", true);
		
		addHierarchicalItem("10.", null, "Name and address of the Dealer or Manufacturer from whom the vehicle was purchased", false);
		addInlineParagraph("(sale certificate and certificate of road worthiness issued by the manufacturer to be enclosed)", 1, 2);
		
		addHierarchicalItem("11.", null, "If ex-army vehicle or imported vehicle, enclose proof", true);
		addHierarchicalItem("12.", null, "Class of vehicle (if motor cycle, whether with or without gear)", true);
		
		addHierarchicalItem("13.", null, "The motor vehicle is", false);
		addHierarchicalItem("", null, "(a) a new vehicle,", true, 1);
		addHierarchicalItem("", null, "(b) ex-army vehicle,", true, 1);
		addHierarchicalItem("", null, "(c) imported vehicle", true, 1);
		addHierarchicalItem("", null, "(d) in use E-rickshaw or E-cart", true, 1);
		addHierarchicalItem("14.", null, "Type of body", true);
		addHierarchicalItem("15.", null, "Type of vehicle", true);
		addHierarchicalItem("16.", null, "Maker's name", true);
		addHierarchicalItem("17.", null, "Month and year of manufacture", true);
		addHierarchicalItem("18.", null, "Number of cylinders", true);
		addHierarchicalItem("19.", null, "Horse power", true);
		addHierarchicalItem("20.", null, "Cubic capacity", true);
		addHierarchicalItem("21.", null, "Maker's classification or if not known, wheel base", true);
		addHierarchicalItem("22.", null, "Chassis No. (Affix Pencil print)", true);
		addHierarchicalItem("23.", null, "Engine Number or Motor Number in case of Battery Operated Vehicles", true);
		addHierarchicalItem("24.", null, "Seating capacity (including driver)", true);
		addHierarchicalItem("24", "A.", "Standing capacity", true);
		addHierarchicalItem("24", "B.", "Sleeper capacity", true);
		addHierarchicalItem("25.", null, "Fuel used in the engine", true);
		addHierarchicalItem("26.", null, "Unladen weight", true);
		addHierarchicalItem("27.", null, "Particulars of previous registration and registered number (if any)", true);
		
		// Page 3: Additional particulars
		doc.addPage();
		y = 18;
        addHierarchicalItem("28.", null, "Colour or colours of body wings and front end", true);
		addPara("I hereby declare that the motor vehicle has not been registered in any State in India.", 6, 10.2, "normal");

		addTitle("ADDITIONAL PARTICULARS TO BE COMPLETED ONLY IN THE CASE OF", 10.2, "bold");
		addTitle("TRANSPORT VEHICLE OTHER THAN MOTOR CAB", 10.2, "bold");
		
		addHierarchicalItem("29.", null, "Number, description, size and ply rating of tyres, as declared by the manufacturer", false);
		addHierarchicalItem("", "(a)", "(a) Front axle         \t=", true, 1);
		addHierarchicalItem("", "(b)", "(b) Rear axle          \t=", true, 1);
		addHierarchicalItem("", "(c)", "(c) Any other axle \t =", true, 1);
		addHierarchicalItem("", "(d)", "(d) Tandem axle   \t =", true, 1);
		
		addHierarchicalItem("30.", null, "Gross vehicle weight", false);
		addHierarchicalItem("", "(a)", "(a) as certified by manufacturer ............ Kgns.", false, 1);
		addHierarchicalItem("", "(b)", "(b) To be registered .................. Kgns.", false, 1);
		
		addHierarchicalItem("31.", null, "Maximum axle weight", false);
		addHierarchicalItem("", "(a)", "(a) Front axle .......................... Kgns.", false, 1);
		addHierarchicalItem("", "(b)", "(b) Rear axle .......................... Kgns.", false, 1);
		addHierarchicalItem("", "(c)", "(c) Any other axle .......................... Kgns.", false, 1);
		addHierarchicalItem("", "(d)", "(d) Tandem axle .......................... Kgns.", false, 1);
		
		addHierarchicalItem("32.", null, "Overall length, width, height, overhang", false);
		addHierarchicalItem("", "(a)", "(a) Overall length", true, 1);
		addHierarchicalItem("", "(b)", "(b) Overall width", true, 1);
		addHierarchicalItem("", "(c)", "(c) Overall height", true, 1);
		addHierarchicalItem("", "(d)", "(d) Over hang", true, 1);
		
		addInlineParagraph("The above particulars are to be filled in for a rigid frame motor vehicle of two or more axles for an articulated vehicle of three or more axles or, to the extent applicable, for trailer, where a second semi-trailer or additional semi-trailer are to be registered with an articulated motor vehicle. The following particulars are to be furnished for each such semi-trailer", 1, 4);
		
        addHierarchicalItem("33.", null, "Type of body", true);
		addHierarchicalItem("34.", null, "Unladen weight", true);
		addHierarchicalItem("35.", null, "Number, description and size of tyres on each axle", true);
		addHierarchicalItem("36.", null, "Maximum axle weight in respect of each axle", true);
		// Item 37 - Insurance certificate with right-aligned block
		const leftColumnWidth = printableWidth - 60; // reserve 60mm for right column
		const rightColumnX = marginLeft + leftColumnWidth;

		// Item 37 (left column)
		const item37Text = "The vehicle is covered by a valid certificate of Insurance under Chapter XI of the Act";
		const leftLines = doc.splitTextToSize(`37. ${item37Text}`, leftColumnWidth);
		doc.text(leftLines, marginLeft, y, { lineHeightFactor: 1.35 });

		// Certificate text (right column)
		const rawInsuranceText = 
		`	Insurance Certificate or 
			Cover Note No. ................
			Date ..........of.............. 
			(Name of company) 
			Valid from .......... to ..........`;

		// Replace one leading tab or 4 spaces from each line
		const leftMargin = "\t ";
		const insuranceText = rawInsuranceText
		.split("\n")
		.map(line => leftMargin + line.trimStart())
		.join("\n");

		const rightLines = doc.splitTextToSize(insuranceText, 65); // max width for right column
		doc.text(rightLines, rightColumnX, y, { lineHeightFactor: 1.35 });

		// Update Y
		const blockHeight = Math.max(leftLines.length, rightLines.length) * 6;
		y += blockHeight + 3;     
		
		// Page 4: Financier and inspection certificate
		doc.addPage();
		y = 18;
        addHierarchicalItem("38.", null, "The vehicle is exempted from insurance. The relevant order is enclosed", true);
		addHierarchicalItem("39.", null, "I have paid the prescribed fee of Rs.", true);
		addPara("Date ............................\t\t\t\t\tSignature or thumb impression of the dealer along with \n\t\t\t\t\t\t\t\t\t     the specimen signature of the owner", 8);
		
		addHierarchicalItem("", "", "Note : The motor vehicle above described is —", false, 0);
		addPara( "\t(i) Subject to Hire-Purchase agreement/ Lease agreement with ............................");
		addPara( "\t(ii) Subject to hypothecation in favour of ............................");
		// The last item should be full width (not indented)
		addPara( "\t(iii) Not held under Hire-Purchase agreement, or lease agreement or subject to Hypothecation Strike \nout whatever is inapplicable, if the vehicle is subject to any such agreement the signature of the Financier \nwith whom such agreement has been entered into is to be obtained.");
		// addPara("Strike out whatever is inapplicable, if the vehicle is subject to any such agreement the signature of the Financier with whom such agreement has been entered into is to be obtained.");
		const lineY = y;          // Y position for dotted lines
		const labelY = y + 5.5;   // Y position for labels (a bit lower)

		// Widths and positions
		const lineWidth = 80;     // Adjust based on your desired line length
		const spaceBetween = 16;  // Space between the two lines

		const leftX = marginLeft;
		const rightX = pageWidth - marginRight - lineWidth;

		// Draw dotted lines
		doc.setFont("helvetica", "normal");
		doc.setFontSize(10);
		doc.text(".".repeat(45), leftX, lineY);   // Left dotted line
		doc.text(".".repeat(45), rightX, lineY);  // Right dotted line

		// Labels below
		doc.setFontSize(9.5); // slightly smaller font for captions
		doc.text(
		"Signature of financier with whom an Agreement of Hire-Purchase, Lease or Hypothecation has been entered into",
		leftX,
		labelY,
		{ maxWidth: lineWidth }
		);

		doc.text(
		"Signature or thumb impression of the registered owner",
		rightX,
		labelY,
		{ maxWidth: lineWidth }
		);

		// Update y for next section
		y = labelY + 8;

		y += 6;
		addTitle("CERTIFICATE OF INSPECTION OF MOTOR VEHICLE WHOSE BODY HAS BEEN", 10.2, "bold");
		addTitle("FABRICATED SEPARATELY TO THE PURCHASED CHASSIS", 10.2, "bold");
		addPara("Certified that the particulars contained in the application are true and that the vehicle complies with the requirements of the Motor Vehicles Act, 1988, and the Rules made thereunder.");
		
		// Date and Signature fields - left aligned
		doc.setFont("helvetica", "normal");
		doc.setFontSize(10.2);
		doc.text("Date ............................", marginLeft, y);
		doc.text("Signature of the Inspecting Authority", pageWidth - marginRight - 80, y);
		y += 6;
		
		doc.text("Ref. No. ......................................", marginLeft, y);
		doc.text("Name ................................................", pageWidth - marginRight - 80, y);
		y += 6;
		
		doc.text("Designation .......................................", pageWidth - marginRight - 80, y);
		y += 6;
		doc.text("Office Endorsement Office of ", pageWidth - marginRight - 80, y);
		y += 6;
		doc.text("the ...............................................", pageWidth - marginRight - 80, y);
		y += 6;
		
		addPara("\tThe above said motor vehicle has been assigned the Registration Number .......... and registered in the \nname of the applicant and the vehicle is subject to an agreement of Hire-Purchase/Lease/Hypothecation with \tthe Financier referred above.");
		
		doc.text("Date ............................", marginLeft, y);
		doc.text("Signature of the Registering Authority", pageWidth - marginRight - 80, y);
		y += 8;
		
		// To section with indented note
		doc.text("To", marginLeft, y);
		y += 6;
		doc.text("The Financier ..........................................................", marginLeft, y);
		y += 6;
		addInlineParagraph("(To be sent by registered post acknowledgement due)", 1, 2);
		
		addPara("\tSpecimen signature or thumb-impression of the person to be registered as Registered Owner and Financier are to be obtained in original application for affixing and attestation by the Registering Authority with office seal in Forms 23 and 24 in such a manner that the part of impression of seal or a stamp and attestation shall fall upon each signature.");
		
		// Specimen signatures section - matching the image layout
		doc.setFont("helvetica", "normal");
		doc.setFontSize(10.2);
		
		// Calculate positions for two-column layout
		const leftColumnX = marginLeft;
		const rightColumnX2 = pageWidth - marginRight - 80;
		
		// Headers
		doc.text("Specimen signature of the Financier", leftColumnX, y);
		doc.text("Specimen signature of the Registered Owner", rightColumnX2, y);
		y += 8;
		
		// Signature lines with proper numbering
		doc.text("(1) .........................................................", leftColumnX, y);
		doc.text("(1) .........................................................", rightColumnX2, y);
		y += 6;
		
		doc.text("(2) .........................................................", leftColumnX, y);
		doc.text("(2) .........................................................", rightColumnX2, y);
		y += 6;

		const pdfBlob = await new Promise((resolve) => {
			const blob = doc.output("blob");
			resolve(blob);
		});
		const pdfUrl = URL.createObjectURL(pdfBlob);
		await new Promise((resolve) => {
			setTimeout(() => {
				window.open(pdfUrl);
				resolve();
			}, 300);
		});
	};

	return (
		<Typography className="main">
			<Button type="primary" onClick={handleExportPdf}>Export PDF</Button>
		</Typography>
	);
};

export default Form20;