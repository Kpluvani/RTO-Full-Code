import React from "react";
import { Button, Typography } from "antd";
import jsPDF from "jspdf";

const { Text } = Typography;

const Form21 = () => {
	const handleExportPdf = async () => {
		const doc = new jsPDF("p", "mm", "a4");
		const pageWidth = doc.internal.pageSize.getWidth();
		const marginLeft = 16;
		const marginRight = 16;
		const printableWidth = pageWidth - marginLeft - marginRight;
		let y = 18;

		// Helpers
		const addTitle = (t, size = 11, style = "bold") => {
			doc.setFont("helvetica", style);
			doc.setFontSize(size);
			doc.text(t, pageWidth / 2, y, { align: "center" });
			y += 6;
		};

		const addPara = (text, gap = 3.5, size = 10.2, style = "normal") => {
			doc.setFont("helvetica", style);
			doc.setFontSize(size);
			const lines = doc.splitTextToSize(text, printableWidth);
			doc.text(lines, marginLeft, y, { lineHeightFactor: 1.35 });
			y += lines.length * 5.2 + gap;
		};

		// Left description + right dotted field
		const addItem = (numText, desc, withRightDots = true) => {
			doc.setFont("helvetica", "normal");
			doc.setFontSize(10.2);

			const leftColumnWidth = printableWidth - 50; // 50mm reserved for right column
			const rightColumnX = marginLeft + leftColumnWidth;

			const leftLines = doc.splitTextToSize(numText ? `${numText} ${desc}` : desc, leftColumnWidth);
			doc.text(leftLines, marginLeft, y, { lineHeightFactor: 1.35 });

			if (withRightDots) {
				const blockHeight = leftLines.length * 5.2;
				doc.text("....................................", rightColumnX, y, { align: "left" });
				y += blockHeight + 3;
			} else {
				y += leftLines.length * 5.2 + 3;
			}
		};

		// Title block
		addTitle("FORM 21", 11, "bold");
		addTitle("[Refer Rule 47(a) and (b)]", 9.5, "italic");
		addTitle("SALE CERTIFICATE", 11, "normal");
		addPara("To be issued by manufacturer or dealer or registered E-rickshaw or E-cart Association (in case of E-rickshaw or E-cart) or officer of Defence Department (in case of military auctioned vehicles) for presentation alongwith the application for registration of motor vehicle.");

		// Part headings and content
		addTitle("Part I : In case of application for registration of fully built", 10.2, "bold");
		addTitle("motor vehicle made by owner", 10.2, "bold");
		addPara("\tCertified that .............................. (brand name of the vehicle) has been delivered by us to .............................. on .............................. (date)");

		addTitle("Part II : In case of application for registration of fully built", 10.2, "bold");
		addTitle("motor vehicle made by dealer", 10.2, "bold");
		addPara("\tCertified that .............................. (brand name of the vehicle) has been agreed to be sold by us to .............................. on .............................. (date) and the vehicle will be delivered by us to .............................. only after the registration mark assigned by the registering authority under Section 41(6) is displayed on the motor vehicle as per proviso to sub-section (6) of Section 41.");

		addTitle("Part III : In case of purchase of chassis", 10.2, "bold");
		addPara("\tCertified that .............................. (chassis) has been temporarily delivered by us on .............................. (date) to ..............................");

		addTitle("Part IV : Applicable in case of Part I, Part II and Part III", 10.2, "bold");

		addItem("Name of the buyer......................................................", "", false);
		addItem("Mobile Number...........................................................", "", false);
		addItem("Son/Wife/daughter of..................................................", "", false);
		addPara("Address (permanent)........................................................................................................................................");
		addPara("(temporary).......................................................................................................................................................");
		addItem("The vehicle is held under agreement of hire-purchase/lease/hypothecation", "with", true);
        y += 4;


		addTitle("The details of the vehicle are given below :", 10.2, "bold");
		addItem("1.", "Class of vehicle", true);
		addItem("2.", "Maker’s name", true);
		addItem("3.", "Chassis No.", true);
		addItem("4.", "Engine No. or motor number in the case of Battery Operated Vehicles", true);
		addItem("5.", "Horse power or cubic capacity", true);
		addItem("6.", "Number of cylinders", true);
		addItem("7.", "Month and year of manufacture", true);
		addItem("8.", "Seating capacity (including driver)", true);
		addItem("9A.", "Standing capacity", true);
		addItem("9B.", "Sleeper capacity", true);

        doc.addPage();
        y = 18;
		        
		addItem("10.", "Unladen weight", true);
		addItem("11.", "Maximum axle weight and number and description of tyres (in case of transport vehicle)", false);
		addItem("", "\t(a) Front axle", true);
		addItem("", "\t(b) Rear axle", true);
		addItem("", "\t(c) Any other axle", true);
		addItem("", "\t(d) Tandem axle", true);
		addItem("12.", "Colour or colours of the body", true);
		addItem("13.", "Gross vehicle weight", true);
		addItem("14.", "Type of body", true);

		addPara("* Strike out whichever is inapplicable.", 8, 9.8, "italic");

		// Signature block (bottom right)
		doc.setFont("helvetica", "normal");
		doc.setFontSize(10.2);
		const signatureText = doc.splitTextToSize(
			"Signature of the manufacturer or dealer or officer of Defence Department or registered E-rickshaw or E-cart Association",
			70
		);
		doc.text(signatureText, pageWidth - marginRight - 70, y + 10, { align: "left", lineHeightFactor: 1.35 });

		const pdfBlob = await new Promise((resolve) => {
			const blob = doc.output('blob');
			resolve(blob);
		});
		const pdfUrl = URL.createObjectURL(pdfBlob);
		await new Promise((resolve) => {
			setTimeout(() => {
				window.open(pdfUrl);
				resolve();
			}, 1000);
		});
	};

	return (
		<Typography className="main">
			<Button type="primary" onClick={handleExportPdf}>Export PDF</Button>
		</Typography>
	);
};

export default Form21;